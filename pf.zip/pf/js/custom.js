$(setup)
function setup() {
      $('.intro select').zelect({})
    }
	
	
	
	// change style for select box
        $(".selectbox").selectbox();