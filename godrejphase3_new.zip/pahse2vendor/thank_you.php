<?php
session_start();

// Retrieve the values from session variables
$email = $_SESSION['email'];

// Clear the session variables after use
unset($_SESSION['email']);
?>
<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="facebook-domain-verification" content="j5gfertm2w2518vsz08dmzoga1i9cn" />
    <meta http-equiv = "refresh" content = "2; url =https://godrej-parkretreat-bangalore.godrejproperties-ltd.in" />
    <link href="css/" rel="stylesheet" type="text/css" media="all">
    <title>Thank you</title>

        <!-- Favicon -->
  <link rel="icon" href="img/favicon.ico">

    <style>
        .thank{
            font-size: 70px;
            text-align: center;
            padding: 50px;
            color: #2d4165;
        }
    </style>

</head>

<body style="background: whitesmoke;">

        <p class="thank">Thank you for Submitting..<br><span style="font-size:20px;"><?php echo "Email: " . $email;?></span></p>
        <div style="text-align: center;">
            <a href="https://godrejnewlaunch-sarjapur.godrejproperties-ltd.in/"><button class="btn btn-primary" style="font-size: 20px;">Visit Our Site</button></a>
        </div>
    <!--         <script>-->
    <!--  var enhanced_conversion_data = {};-->
    <!--  window.addEventListener('load', function() {-->
    <!--    gtag('config', 'AW-11139463293', {-->
    <!--      'allow_enhanced_conversions': true-->
    <!--    });-->
    <!--    if (window.location.pathname.includes("/thank_you.php") && window.location.pathname.includes("forvendorgprnew/pahse2vendor")) {-->
    <!--      var eCemail = document.querySelector('.thank span').innerText.split(' ')[document.querySelector('.thank span').innerText.split(' ').length -1];-->
    <!--      enhanced_conversion_data.email = eCemail-->
    <!--      gtag('event', 'conversion', {-->
    <!--        'send_to': 'AW-11139463293/mgedCOyP6bIYEP3w2r8p'-->
    <!--      });-->
    <!--    }-->
    <!--  });-->
    <!--</script>-->
</body>

</html>
