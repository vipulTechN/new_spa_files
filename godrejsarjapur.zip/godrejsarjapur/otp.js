 var otpG = Math.floor(1000 + Math.random() * 9000).toString();
    function sendOTP() {
  var mobileNumber = document.querySelector('input[name="phone"]').value;

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var response = this.responseText;

      // Check if the response contains a success message
      if (response.includes("success")) {
        document.getElementById("otpResult").innerText = "OTP sent successfully!";
      } else {
        document.getElementById("otpResult").innerText = "Failed to send OTP.";
      }
      // You can perform further actions based on the response
    }
  };

  var url = "https://www.fast2sms.com/dev/bulkV2?authorization=E2SO3Qc7HLJc7foeIWZrM8CAGhMFVV07L5YU9ZpykVYCWQ4BhTEBocweBqy6&variables_values="+otpG+"&route=otp&numbers=" + encodeURIComponent(mobileNumber);
  xhttp.open("GET", url, true);
  xhttp.send();
}
function verifyOTP() {
  var enteredOTP = document.getElementById("otpInput").value;
//   var sentOTP = localStorage.getItem("sentOTP");

  if (enteredOTP === otpG) {
    document.getElementById("otpResult1").innerText = "OTP verification successful!";
  } else {
    document.getElementById("otpResult1").innerText = "OTP verification failed.";
  }
}