<?php
session_start();

// Retrieve the values from session variables
$email = $_SESSION['email'];

// Clear the session variables after use
unset($_SESSION['email']);
?>
<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv = "refresh" content = "2; url =https://godrej-ananda-north-bangalore.godrejproperties-ltd.in/" />
    <link href="css/" rel="stylesheet" type="text/css" media="all">
    <title>Thank you</title>

        <!-- Favicon -->
  <link rel="icon" href="img/favicon.ico">

    <style>
        .thank{
            font-size: 70px;
            text-align: center;
            padding: 50px;
            color: #2d4165;
        }
    </style>
    
    <!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=G-KGJQGQD547"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-KGJQGQD547'); </script>
    
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-11139463293"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-11139463293');
    </script>
    
    <!-- Event snippet for Godrej Ananda New Phase (1) conversion page -->
    <script>
      gtag('event', 'conversion', {'send_to': 'AW-11139463293/AZZwCMiw7b4YEP3w2r8p'});
    </script>
    
</head>

<body style="background: whitesmoke;">

        <p class="thank">Thank you for Submitting..<br><span style="font-size:20px;"><?php echo "Email: " . $email;?></span></p>
        <div style="text-align: center;">
            <a href="https://godrejproperties-ltd.in/godrej-ananda/new-project-north-bangalore/"><button class="btn btn-primary" style="font-size: 20px;">Visit Our Site</button></a>
        </div>
</body>

</html>
