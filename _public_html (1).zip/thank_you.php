<?php
session_start();

// Retrieve the values from session variables
$email = $_SESSION['email'];

// Clear the session variables after use
unset($_SESSION['email']);
?>
<!DOCTYPE html>
<html lang="">
<head>
    
    <!-- Google tag (gtag.js) -->
    <!--<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11139486625"></script>-->
    <!--<script>-->
    <!--  window.dataLayer = window.dataLayer || [];-->
    <!--  function gtag(){dataLayer.push(arguments);}-->
    <!--  gtag('js', new Date());-->
    
    <!--  gtag('config', 'AW-11139486625');-->
    <!--</script>-->
    
    <!-- Event snippet for Amber Meadows conversion page -->
    <!--<script>-->
    <!--  gtag('event', 'conversion', {'send_to': 'AW-11139486625/8K4wCJrn_ZYYEKGn3L8p'});-->
    <!--</script>-->
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/" rel="stylesheet" type="text/css" media="all">
    <title>Thank you</title>

        <!-- Favicon -->
  <link rel="icon" href="img/favicon.ico">

    <style>
        .thank{
            font-size: 70px;
            text-align: center;
            padding: 50px;
            color: #2d4165;
        }
    </style>
    
    <!-- Meta Pixel Code -->
    <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '759775781793341');
      fbq('track', 'PageView');
    </script>
    
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-7D86EH9CD1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-7D86EH9CD1');
    </script>
    
    <script>
  var enhanced_conversion_data = {
    "email": ''  
  }; 
</script>
<!-- Global site tag (gtag.js) - Google Ads: 11139486625 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11139486625"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config','AW-11139486625', {'allow_enhanced_conversions':true});
</script>
    
</head>

<body style="background: whitesmoke;">
    
        <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=759775781793341&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Meta Pixel Code -->

         <p class="thank">Thank you for Submitting.. <br><span style="font-size:20px;"><?php echo "Email: " . $email;?></span></p>
        <div style="text-align: center;">
            <a href="/index.html"><button class="btn btn-primary" style="font-size: 20px;">Visit Our Site</button></a>
        </div>
        
        <script>
  window.addEventListener('load',function(){
   if(window.location.href.includes('/thank_you.php')){
      enhanced_conversion_data.email = document.querySelectorAll('.thank span')[0].innerText.split('Email:')[1].trim()
      gtag('event', 'conversion', {'send_to': 'AW-11139486625/8K4wCJrn_ZYYEKGn3L8p'});
 }
 });
</script>
        
</body>

</html>
