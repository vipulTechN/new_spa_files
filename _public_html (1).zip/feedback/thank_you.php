<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/" rel="stylesheet" type="text/css" media="all">
    <title>Thank you</title>
    <link rel="icon" href="assets/img/logo1.jpg">
    <style>
    .footer-like,.thank,.wrapper-2{text-align:center}.footer-like p,.wrapper-2 p{margin:0;font-family:'Source Sans Pro',sans-serif;letter-spacing:1px}.thank{font-size:70px;padding:50px;color:#2d4165}*{box-sizing:border-box}body{background:#fff;background:linear-gradient(to bottom,#fff 0,#e1e8ed 100%);height:100%;margin:0;background-repeat:no-repeat;background-attachment:fixed}.wrapper-1{width:100%;height:100vh;display:flex;flex-direction:column}.wrapper-2{padding:30px}h1{font-family:'Kaushan Script',cursive;font-size:4em;letter-spacing:3px;color:#5892ff;margin:0 0 20px}.wrapper-2 p{font-size:1.3em;color:#aaa}.go-home{color:#fff;background:#5892ff;border:none;padding:10px 50px;margin:30px 0;border-radius:30px;text-transform:capitalize;box-shadow:0 10px 16px 1px #aec7fb}.footer-like{margin-top:auto;background:#d7e6fe;padding:6px}.footer-like p{padding:4px;color:#5892ff}.footer-like p a{text-decoration:none;color:#5892ff;font-weight:600}@media (min-width:360px){h1{font-size:4.5em}.go-home{margin-bottom:20px}}@media (min-width:600px){.content{max-width:1000px;margin:0 auto}.wrapper-1{height:initial;max-width:620px;margin:50px auto 0;box-shadow:4px 8px 40px 8px rgba(88,146,255,.2)}}
    </style> 
</head>
<body style="background: whitesmoke;">
        <div class=content>
  <div class="wrapper-1">
    <div class="wrapper-2">
      <h1>Thank you !</h1>
      <p>We Will Reach You Soon... </p>
     <a href="/"> <button class="go-home">
      Go Home
      </button></a>
    </div>
    <div class="footer-like">
      <p>Email not received?
       <a href="/">Click here to send again</a>
      </p>
    </div>
</div>
</div>     
</body>
</html>
