<?php 
if(isset($_POST['submit'])){ 
      
    $from = $_POST['email']; // this is the sender's Email address
    $pname = $_POST['pname'];
    $cname = $_POST['cname'];
    $message ="";
    $rating = $_POST['rating'];
    $srating = $_POST['srating'];
    $sratingf = $_POST['sratingf'];
    $status = $_POST['status'];
    $cemail = $_POST['cemail'];
    $cmobile = $_POST['cphone'];
    $feedback = $_POST['text'];
    $subject = "Feedback From Client side";
    $message = "property: ".$property."\n"."Name : ".$cname ."\n"."Email : ".$cemail."\n" . "Mobile : ".$cmobile."\n" . "Rating: ".$rating."\n". "Booking Confermations: ".$srating."\n". "Sales Person Feedback: ".$sratingf."\n". "Booking Status: ".$status."\n". "Message: ".$feedback."\n". $_POST['message']."\n "."\n";
    $message .= "This email is coming from Site Visit Custumer Page Form Submission";
     include_once("class.phpmailer.php");
         $mail = new PHPMailer();
         
         

         $mail->Priority = 1;
    $mail->From = $from;
    $mail->FromName = $name;
    $mail->Sender = $from;
    $mail->ReturnPath = $from;
    $mail->AddReplyTo($from, $from);
    // $mail->AddBCC("vipulmishra@searchhomesindia.com , vipulmishra@searchhomesindia.com");
    $mail->AddAddress("info@searchhomesindia.com, info@searchhomesindia.com");
    
    //$mail->AddBCC("digitalrakeshdasi@gmail.com, digitalrakeshdasi@gmail.com");
     //$mail->AddBCC("ganesh.smrholdings@gmail.com, ganesh.smrholdings@gmail.com");
    // $mail->AddBCC("nandithahema@gmail.com, nandithahema@gmail.com");
    // $mail->BCCAddress("digitalrakeshdasi@gmail.com");
     
         $mail->Body = $message;
         
             $mail->AltBody = "";
         $mail->Subject = $subject ;

                $sent =$mail->Send();
                
    
					?>
						<script>
							window.location.href='thank_you.php';
						</script>
					<?php
    }
?>