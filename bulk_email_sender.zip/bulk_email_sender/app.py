from flask import Flask, render_template, request, redirect, url_for, flash
from flask_mail import Mail, Message
import pandas as pd
import os

app = Flask(__name__)
app.secret_key = 'api-90C497F0AB5B48C18D8A081919EE88D8'

# Configure the email server
app.config['MAIL_SERVER'] = 'mail.smtp2go.com'
app.config['MAIL_PORT'] = 2525
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'searchhomesindia.com'
app.config['MAIL_PASSWORD'] = 'YZxC3LwK9T55i01P'
app.config['MAIL_DEFAULT_SENDER'] = 'contact@propertycontact.online'  # Make sure this is set

# Print configurations for debugging
# print(f"MAIL_SERVER: {app.config['MAIL_SERVER']}")
# print(f"MAIL_PORT: {app.config['MAIL_PORT']}")
# print(f"MAIL_USE_TLS: {app.config['MAIL_USE_TLS']}")
# print(f"MAIL_USERNAME: {app.config['MAIL_USERNAME']}")
# print(f"MAIL_PASSWORD: {app.config['MAIL_PASSWORD']}")
# print(f"MAIL_DEFAULT_SENDER: {app.config['MAIL_DEFAULT_SENDER']}")

mail = Mail(app)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files or request.files['file'].filename == '':
            flash('No file selected')
            return redirect(request.url)

        file = request.files['file']
        file_path = os.path.join('uploads', file.filename)
        file.save(file_path)

        data = pd.read_excel(file_path)

        if 'Email' not in data.columns:
            flash('The file must contain an "Email" column')
            return redirect(request.url)

        subject = request.form['subject']
        message = request.form['message']

        recipients = data['Email'].dropna().tolist()
        for email in recipients:
            try:
                # Render the HTML template with the user's subject and message
                html_content = render_template('email_template.html', subject=subject, message=message)
                msg = Message(subject=subject, recipients=[email], html=html_content)
                msg.sender = app.config['MAIL_DEFAULT_SENDER']
                mail.send(msg)
                print(f'Successfully sent email to {email}')
            except Exception as e:
                flash(f'Failed to send email to {email}: {str(e)}')
                print(f'Error sending email to {email}: {str(e)}')

        flash('Emails sent successfully')
        return redirect(url_for('index'))

    return render_template('index.html')

if __name__ == '__main__':
    if not os.path.exists('uploads'):
        os.mkdir('uploads')
    app.run(debug=True, host='192.168.1.9', port=5000)