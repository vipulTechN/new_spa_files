<?php
session_start();

// Retrieve the values from session variables
$email = $_SESSION['email'];

// You can now use these variables to display or process the data
// echo "Email: " . $email . "<br>";

// Clear the session variables after use
unset($_SESSION['email']);
?>

<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/" rel="stylesheet" type="text/css" media="all">
    <title>Thank you</title>

        <!-- Favicon -->
  <link rel="icon" href="img/favicon.ico">

    <style>
        .thank{
            font-size: 70px;
            text-align: center;
            padding: 50px;
            color: #2d4165;
        }
    </style>
    <!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=G-83J6MR335F"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-83J6MR335F'); </script>
    
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11139553754"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11139553754');
</script>
    
<!-- Event snippet for TPC Hyderabad conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-11139553754/fu7MCO_U-fQYENqz4L8p'});
</script>
    
</head>

<body style="background: whitesmoke;">

        <p class="thank">Thank you for Submitting.. <br><span style="font-size:20px;"><?php echo "Email: " . $email;?></span></p>
        <div style="text-align: center;">
            <a href="/the-prestige-city/shamshabad-hyderabad/"><button class="btn btn-primary" style="font-size: 20px;">Visit Our Site</button></a>
        </div>
</body>
</html>
