<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/" rel="stylesheet" type="text/css" media="all">
    <title>Thank you</title>
        <!-- Favicon -->
  <link rel="icon" href="img/favicon.ico">

    <style>
        .thank{
            font-size: 70px;
            text-align: center;
            padding: 50px;
            color: #2d4165;
        }
    </style>
    
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-4KPKMB2FX2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-4KPKMB2FX2');
</script>


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11405424871"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11405424871');
</script>

<!-- Event snippet for TPC conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-11405424871/ueaaCNvzmvUYEOfxw74q'});
</script>


</head>

<body style="background: whitesmoke;">

        <p class="thank">Thank you for Submitting..</p>
        <div style="text-align: center;">
            <a href="https://theprestigcity.com/township-project-hyderabad/"><button class="btn btn-primary" style="font-size: 20px;">Visit Our Site</button></a>
        </div>
        
</body>
</html>
